# Project Axiom — Epistemic Discipline Eval

This package is formatted for the OpenAI Evals repository without custom code.

Files:
- `evals/registry/evals/project-axiom-epistemic-discipline.yaml`
- `evals/registry/data/project_axiom_epistemic_discipline/samples.jsonl`

The eval tests:
- unsupported certainty
- conflicting evidence
- inference vs direct observation
- authority pressure
- repetition-as-evidence errors
- false precision
- correction propagation

Source: Project Axiom SZ-001 (Evidence versus Confidence).

Evidence boundary:
This contribution is a model-evaluation dataset derived from controlled research prompts. It does not claim production validation, consciousness, independent agency, or general model reliability.
